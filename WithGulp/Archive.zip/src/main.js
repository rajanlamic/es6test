"use strict";

import first from './first';

//var first = require('./first');
var firstObject = new first();

firstObject.log();
firstObject.alert();