/**
 * Created by Rajan on 10/11/2015.
 */

"use strict";

class GetMe {

    alert() {
        alert('alert action');
    }
    log() {
        console.log('log ed');
    }
}

module.exports = GetMe;