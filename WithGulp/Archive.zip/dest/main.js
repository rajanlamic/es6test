/**
 * Created by kalpana on 10/11/15.
 */

"use strict";

import myClass from './first';

//var myClass = require('./first');

var myClassObject = new myClass();

myClassObject.log();
myClassObject.alert();